text = input("Enter a title: ")

length = len(text)

print("The lengh of the title:", length, "characters.")